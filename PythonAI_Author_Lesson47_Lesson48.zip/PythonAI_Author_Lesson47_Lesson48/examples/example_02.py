"""Після блоку 1 відкрийте trace.jsonl в IDE. Знайдіть один run_id і його generate. Напишіть перевірку, що кожен рядок має run_id/stage/status, а API-ключ відсутній. Додайте підрахунок токенів.
Готово, якщо: Кожен рядок розбирається як JSON; ключів і текстів питань немає; usage підсумовано без подвійного рахунку result.
"""
from pathlib import Path
import sys
REPOSITORY = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(REPOSITORY))
from PythonAI_Author_Lesson47_Lesson48.runtime import PACKAGE, session, read_documents, validate_answer
import json
import time
import uuid

def main():
    trace=PACKAGE/'artifacts/trace.jsonl'
    rows=[json.loads(line) for line in trace.read_text(encoding='utf-8').splitlines()]
    for row in rows[-5:]:
        print({k:row.get(k) for k in ('run_id','stage','status','duration_ms','input_tokens','output_tokens')})

if __name__=="__main__":
    main()
